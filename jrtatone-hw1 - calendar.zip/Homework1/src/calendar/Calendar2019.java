package calendar;

import java.util.Scanner;
//Create first Class
public class Calendar2019 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
// initialize variables
		int year;
		int daysInMonth= 0;
		
		
//import scanner and print opening statements
		java.util.Scanner keyboard = new Scanner (System.in);
		System.out.println("This program displays a calendar.  You need to provide the year, \n" + 
				"and the day of the week on which January 1 falls");
		System.out.println("Enter the year for which you would like a calendar: ");
		year = keyboard.nextInt();
		System.out.println("Enter the code number for the day of the week on which January 1 falls: 0- Sun  1- Mon  2- Tue  3- Wed  4- Thu  5- Fri  6- Sat");
		System.out.println("Enter the day code now: ");
//initialize dayCode and create user input
		int dayCode = keyboard.nextInt();
		
		
//loop for months; printing month, year and days
		for(int month = 1; month <= 12; month++) {
			
			if(month == 1) {
				System.out.println("January" + year);
				daysInMonth = 31; }
			if(month == 2) {
		// leap year calculations
				if(year%4 == 0 && year%100 != 0)
					daysInMonth = 29;
				else if(year%400 == 0)
					daysInMonth = 29;
				else daysInMonth = 28;
				System.out.println("February" + year);
				}
			if(month == 3) {
				System.out.println("March" + year);
				daysInMonth = 31; }
			if(month == 4) {
				System.out.println("April" + year);
				daysInMonth = 30; }
			if(month == 5) {
				System.out.println("May" + year);
				daysInMonth = 31; }
			if(month == 6) {
				System.out.println("June" + year);
				daysInMonth = 30; }
			if(month == 7) {
				System.out.println("July" + year);
				daysInMonth = 31; }
			if(month == 8) {
				System.out.println("August" + year);
				daysInMonth = 31; }
			if(month == 9) {
				System.out.println("September" + year);
				daysInMonth = 30; }
			if(month == 10) {
				System.out.println("October" + year);
				daysInMonth = 31; }
			if(month == 11) {
				System.out.println("November" + year);
				daysInMonth = 30; }
			if(month == 12) {
				System.out.println("December" + year);
				daysInMonth = 31; }
//days of the week being printed
		System.out.println("  Sun  Mon  Tue  Wed  Thu  Fri  Sat");
		for(int i=0; i<dayCode; i++) {
			//spacing
			System.out.print("     ");
		}
		
		for(int date=1; date<= daysInMonth; date++) {
			System.out.printf("%5d", date);
			if((date + dayCode) % 7 == 0) {
				System.out.println();
			}
			
			
		}	
		System.out.println();
		dayCode = ((dayCode + daysInMonth) % 7);
		
		}	
	}

	private static void dayCode(int i) {
		// TODO Auto-generated method stub
		
	}
	}
	


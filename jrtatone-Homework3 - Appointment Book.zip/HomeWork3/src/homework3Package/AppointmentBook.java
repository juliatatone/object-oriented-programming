package homework3Package;

import java.util.ArrayList;
import java.util.GregorianCalendar;

/**
 * Create class AppointmentBook that 
 * @author juliatatone
 *
 */
public class AppointmentBook {
	ArrayList<Event> event;
	ArrayList<Event> datedevents;
	public AppointmentBook() {
	this.event = new ArrayList <Event>();
	}
	/**
	 * method to add an event, to the ArrayList keeping track of the events, if there is no conflicting event
	 * @param e
	 */
	public void addEvent(Event e) {
		for(Event e1: event) {
			if(e1.equals(e)) {
				return;
			}
		}
		event.add(e);
	}
	/**
	 * adds events to ArrayList of Events for the given date
	 * @param d
	 * @return
	 */
	public ArrayList<Event> getEventsForDate(GregorianCalendar d) {
		ArrayList<Event> datedevents = new ArrayList<Event>();
			for (Event d1 : event) {
				if (d1.getDate().equals(d)) {
					datedevents.add(d1);
		}
	}
			return datedevents;
	
}
}

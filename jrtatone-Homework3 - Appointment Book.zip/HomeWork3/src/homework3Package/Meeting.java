package homework3Package;
import java.util.ArrayList;
import java.util.GregorianCalendar;
/**
 * create Class Meeting that extends abstract class Event, and maintains an ArrayList for the names of the attendees
 * @author juliatatone
 *
 */
public class Meeting extends Event {
	ArrayList<String> attendees;
	/**
	 * Constructor for Meeting that takes same parameters as Event
	 * Create the new ArrayList called attendees
	 * @param contact
	 * @param date
	 */
	public Meeting(Contact contact, GregorianCalendar date) {
		super(contact, date);
		this.attendees = new ArrayList <String>();
	}
	/**
	 * Void method that adds the names of the attendees to the ArrayList
	 * @param name
	 */
	public void addAttendee(String name) {
	attendees.add(name);
	}
	/**
	 * 
	 * @return the ArrayList
	 */
	public ArrayList<String> getAttendees() {
		return this.attendees;
	}
	/**
	 * toString method for Meeting, taking the toString method from Event
	 */
	public String toString() {
		return super.toString();
	}

}

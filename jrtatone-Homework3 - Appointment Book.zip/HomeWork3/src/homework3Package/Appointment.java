package homework3Package;
import java.util.GregorianCalendar;
/**
 * Create class Appointment, that takes 3 parameters but only one new field, other fields extended from Event.  
 * Extends from abstract class Event
 * @author juliatatone
 *
 */
public class Appointment extends Event {
	private String type;
	/**
	 * Constructor for Appointment, with all three parameters
	 * @param contact
	 * @param date
	 * @param type
	 */
	public Appointment(Contact contact, GregorianCalendar date, String type) {
		super(contact, date);
		this.type = type;
	}
	/**
	 * getter for String type (specifying type of appointment)
	 * @return
	 */
	public String getType() {
		return this.type;
	}
	/**
	 * toString method for Appointment, taking the toString method from Event
	 */
	public String toString() {
		return  this.type + super.toString() ;
	}

}

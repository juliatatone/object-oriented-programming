package homework3Package;
/**
 * create class Contact, has two fields: person's name and phone number
 * @author juliatatone
 *
 */
public class Contact {
	private String name;
	private int phone;
	/**
	 * constructor for Contact with both parameters
	 * @param name
	 * @param phone
	 */
	public Contact(String name, int phone) {
		this.name = name;
		this.phone = phone;
	}
	/**
	 * getter
	 * @return string name
	 */
	public String getName(){
		return this.name;
	}
	/**
	 * getter
	 * @return integer phone
	 */
	public int getPhone(){
		return this.phone;
	}
	/**
	 * toString method for Contact
	 */
	public String toString() {
		return this.name + " " + this.phone;
	}
}

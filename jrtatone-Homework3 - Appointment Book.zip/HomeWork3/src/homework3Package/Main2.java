package homework3Package;

import java.util.GregorianCalendar;

public class Main2 {
	public static void main(String[] args) {
	//test contacts
	Contact julia = new Contact ("Julia",6049028);
	Contact vibhuti = new Contact("vibhuti", 9278888);
	System.out.println(julia + "\n" +"" +  vibhuti);
	
	//test Appointment
	GregorianCalendar newDate = new GregorianCalendar(2016, 11, 17, 8, 0);
	Appointment extraHelp = new Appointment(julia ,newDate, "tutoring");
	System.out.println(extraHelp);
	
	//test meeting and adding names to ArrayList
	GregorianCalendar newMeeting = new GregorianCalendar(2019, 04, 01, 8, 0);
	Meeting meetingOne = new Meeting (vibhuti, newMeeting);
	meetingOne.addAttendee("Joe");
	System.out.println(meetingOne);
	
	
	//test appointment book and adding events
	AppointmentBook book = new AppointmentBook();
	book.addEvent(extraHelp);
	System.out.println(book);
	
	
	
	}
}

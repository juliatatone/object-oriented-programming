package homework3Package;
import java.util.GregorianCalendar;
/**
 * create an abstract class for Event, with two fields of type class Contact (name and phone number) and type GregorianCalendar (date of event)
 * GregorianCalendar has a year, month, dayOfMonth, hourOfDay, and minute
 * @author juliatatone
 *
 */
public abstract class Event {
	private Contact contact;
	private GregorianCalendar date;
	
	/**
	 * constructor for Event taking both parameters
	 * @param contact
	 * @param date
	 */
	public Event(Contact contact, GregorianCalendar date) {
		this.contact = contact;
		this.date = date;
	}
	/**
	 * getter for contact 
	 * @return type Contact contact
	 */
	public Contact getContact() {
		return this.contact;
	}
	/**
	 * getter for the date
	 * @return type GregorianCalendar date
	 */
	public GregorianCalendar getDate() {
		return this.date;
	}
	/**
	 * toString method for Event
	 * establish the api for GregorianCalendar 
	 */
	public String toString() {
		int month = date.get(GregorianCalendar.MONTH);
		int yr = date.get(GregorianCalendar.YEAR);
		int day = date.get(GregorianCalendar.DAY_OF_MONTH);
		int hour = date.get(GregorianCalendar.HOUR);
		int minute = 0;
		return this.contact + " " + yr+ " " + month+ " " + day+ " "+ hour+ " "+ minute;
		
	}
}

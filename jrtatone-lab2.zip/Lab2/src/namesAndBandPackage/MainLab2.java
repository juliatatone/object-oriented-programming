package namesAndBandPackage;
/**
 * Main class 
 * @author juliatatone
 *
 */
public class MainLab2 {

	public static void main(String[] args) {
		Person diane = new Person("Diane");
		Person joe = new Person("Joe");
		Band band1 = new Band();
		
		band1.addMember(diane);
		band1.addMember(joe);
		System.out.println(band1);
		
		band1.getBand().size();
		System.out.println(band1.getBand().size());
	}
}

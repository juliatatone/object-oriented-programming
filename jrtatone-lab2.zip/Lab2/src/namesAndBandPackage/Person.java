package namesAndBandPackage;
import java.util.ArrayList;
/**
 * A Person with a name.
 * @author juliatatone
 *
 */
public class Person {
	String name;
/**
 * Constructor
 * @param name
 */
	public Person(String name) {
		this.name = name;	
	}
/**
 * gets the name of person.
 * @return the person's name
 * @return
 */
	public String getname() {
		return this.name;
	}
}

package lab5Package;

import static org.junit.Assert.*;
import org.junit.*;

public class BoaTest {
	private Boa jen;
	private Boa ken;
	@Before
	public void setUp() throws Exception {
	 jen = new Boa("Jennifer", 2, "grapes");
	 ken = new Boa ("Kenneth", 3, "granola bars");
	}
	

	@Test
	public void testIsHealthy() {

		assertEquals("granola bars",ken.getFavoriteFood());
		assertEquals("granola bars", jen.getFavoriteFood());
	}

	@Test
	public void testFitsInCage(Boa length, Boa cageLength) {
		assertEquals(length == cageLength);
	}
	@Test
	public void testlengthInInches(Boa inches, Boa cageLength) {
		
		assertEquals(inches == cageLength);
	}
}

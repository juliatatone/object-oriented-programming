package lab3Package;
import java.util.Scanner;
import lab3Package.Precint;
public class PrecintProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Precint worcester12;
		worcester12 = new Precint("Worcester12", "130 Winter Street", 1673);
		System.out.println(worcester12);
		System.out.println("Enter Population: ");
		Scanner keyboard = new Scanner(System.in);
		int amount = keyboard.nextInt();
		keyboard.nextLine();
		System.out.println("Enter Precint: ");
		String preName = keyboard.nextLine();
		System.out.println("Enter Address: ");
		String preAddr = keyboard.nextLine();
		Precint newPrecint = worcester12.grow(amount);
		System.out.println(newPrecint);
		System.out.println("Precint: " + preName +" Address: " + preAddr + " Population: " + amount);
		keyboard.close();
	}
	
}

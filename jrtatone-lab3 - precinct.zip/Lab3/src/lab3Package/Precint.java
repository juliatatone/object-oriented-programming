package lab3Package;

import java.util.Scanner;

public class Precint {
	private String name;
	private String address;
	private int population;
	
public Precint(String name, String address, int population) {
	this.name = name;
	this.address = address;
	this.population = population;
	}
public String getName() {
	return this.name;
}
public String getAddress() {
	return this.address;
}
public int getPopulation() {
	return this.population;
}
public String toString() {
	return ("Precint: " + this.name + ", " + "Address: " + this.address + ", " + "Population: " + this.population);
}

public Precint grow(int amount) {
	
	Precint newPopulation = new Precint(name, address, amount + this.population);
	return newPopulation;
}

}

package homework6Package;
/**
 * Julia Tatone
 */
//STEP 1. Import required packages
import java.sql.*;

public class HW6SuppliedFile {

	// JDBC driver name and database URL
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
	static final String DB_URL = "jdbc:mysql://mysql.wpi.edu/";
	static final String DB_NAME = "small_gs_example";

	//  Database credentials

	static final String USER = "restricted_gs";  
	static final String PASS = "jMLuBo";  

	public static void main(String[] args) {
		Connection conn = null;
		Statement stmt;


		try{
			//STEP 2: Register JDBC driver
			//  IF AN EXCEPTION OCCURS HERE, MAKE SURE YOU'VE ADDED THE MYSQL 
			//  CONNECTOR FILE TO THE PROJECT'S BUILD PATH
			Class.forName(JDBC_DRIVER);

			//STEP 3: Open a connection
			System.out.println("Connecting to database...");
			conn = DriverManager.getConnection(DB_URL + DB_NAME, USER, PASS);


			//STEP 4: Execute a query
			System.out.println("Creating statement...");
			stmt = conn.createStatement();

			String sql = "SELECT * FROM PARTICIPANT WHERE PARTICIPANT_NM = 'Amanda'";
			String sql1 = "SELECT * FROM MEETING";
			String sql2 = "SELECT MEETING.MEETING_NM FROM TIME_SLOT, MEETING WHERE TIME_SLOT.DAY_OF_WEEK = 'Monday' AND TIME_SLOT.MEETING_ID = MEETING.MEETING_ID";
			String sql3 = "SELECT COUNT(PARTICIPANT.PARTICIPANT_ID), MEETING.MEETING_NM FROM PARTICIPANT,MEETING, PARTICIPANT_MEETING_REL WHERE MEETING.MEETING_ID = 1105 AND PARTICIPANT.PARTICIPANT_ID = PARTICIPANT_MEETING_REL.PARTICIPANT_ID AND MEETING.MEETING_ID = PARTICIPANT_MEETING_REL.MEETING_ID";
			String sql4 = "SELECT DISTINCT PARTICIPANT.PARTICIPANT_NM, PARTICIPANT.PARTICIPANT_ID FROM PARTICIPANT, PARTICIPANT_MEETING_REL WHERE PARTICIPANT_MEETING_REL.IS_OWNER = 1 AND PARTICIPANT.PARTICIPANT_ID = PARTICIPANT_MEETING_REL.PARTICIPANT_ID";
			String sql5 = "SELECT MEETING.MEETING_NM, PARTICIPANT.PARTICIPANT_NM FROM MEETING, TIME_SLOT, PARTICIPANT WHERE TIME_SLOT.DAY_OF_WEEK = 'Tuesday' AND PARTICIPANT.PARTICIPANT_ID = 768 AND MEETING.MEETING_ID = TIME_SLOT.MEETING_ID";
			String sql6_1 = "UPDATE MEETING SET MEETING_NM = 'Julias Meeting' WHERE MEETING_ID = 1081";
			String sql6_2 = "SELECT * FROM MEETING WHERE MEETING_ID = 1081";
			
			ResultSet rs = stmt.executeQuery(sql);


			//STEP 5: Extract data from result set
			while(rs.next()){
				String str = rs.getString("PARTICIPANT_NM");
				int id = rs.getInt("PARTICIPANT_ID");
				System.out.println("Participant " + str + " has ID " + id);
				System.out.println("");
			}
			/**
			 * problem 1 query
			 */
			rs = stmt.executeQuery(sql1);
			ResultSetMetaData rsmd = rs.getMetaData();
			int numberOfColumns = rsmd.getColumnCount();
			System.out.println("PROBLEM 1: Column names for the MEETING relation");
			System.out.println("Number of columns: " + numberOfColumns);
			
			/**
			 * getting the name of column for query 1
			 */
			int i;
			for (i = 1; i <= numberOfColumns; i++) {
				String columnName = rsmd.getColumnName(i);
				System.out.println("Name of column: " + columnName);	
			}
			System.out.println("");

			/**
			 * problem 2 query
			 */
			rs = stmt.executeQuery(sql2);
			System.out.println("PROBLEM 2: Meeting names (that are held on Mondays) for the MEETING and TIME_SLOT relation");
			
			while(rs.next()) {
				String mtng_nm = rs.getString("MEETING_NM");
				int numberOfColumns2 = rsmd.getColumnCount();
				System.out.println("Meeting name is:" + mtng_nm);
			}
			System.out.println("");
			/**
			 * problem 3 query
			 */
			rs = stmt.executeQuery(sql3);
			System.out.println("PROBLEM 3:  Number of Participants in the meeting with meeting ID 1105 for the PARTICIPANT and PARTICIPANT_MEETING_REL relation");
			while(rs.next()) {
				String meeting_nm = rs.getString("MEETING_NM");
				int participants = rs.getInt("COUNT(PARTICIPANT.PARTICIPANT_ID)");
				System.out.println("Number participants in meeting: " + participants );
				System.out.println("Meeting name: " + meeting_nm);
			}
			System.out.println("");
			
			/**
			 * problem 4 query
			 */
			rs = stmt.executeQuery(sql4);
			System.out.println("PROBLEM 4:  Name and ID of participants who run at least one meeting for the PARTICIPANT relation");
			while(rs.next()) {
				String owner_nm = rs.getString("PARTICIPANT_NM");
				int owner_id = rs.getInt("PARTICIPANT_ID");
				int numberOfColumns3 = rsmd.getColumnCount();
				System.out.println("Name: " + owner_nm);
				System.out.println("ID: " + owner_id);
			}
			System.out.println("");
			
			/**
			 * problem 5 query
			 */
			rs = stmt.executeQuery(sql5);
			System.out.println("PROBLEM 5: Names of meetings held on Tuesday with participant with ID 768 for the MEETING and PARTICIPANT relations");
			while(rs.next()) {
				String mtng_nm = rs.getString("MEETING_NM");
				String par_nm = rs.getString("PARTICIPANT_NM");
				int numberOfColumns4 = rsmd.getColumnCount();
				System.out.println("Meeting: " + mtng_nm);
				System.out.println("Participant: " + par_nm);
			}
			System.out.println("");
			
			/**
			 * problem 6 query
			 */
			stmt.executeUpdate(sql6_1);
			rs = stmt.executeQuery(sql6_2);
			System.out.println("PROBLEM 6: Change the name of meeting with ID 1081 from MEETING relation");
			while(rs.next()) {
				String mtng_name = rs.getString("MEETING_NM");
				int mtng_ident = rs.getInt("MEETING_ID");
				int time = rs.getInt("FINAL_TIME_SLOT_ID");
				String state = rs.getString("STATE");
				System.out.println("Meeting name: " + mtng_name);
				System.out.println("Meeting ID: " + mtng_ident);
				System.out.println("Time of meeting: " + time);
				System.out.println("State: " + state);
			}
			System.out.println("");



			//STEP 6: Clean-up environment
			rs.close();
			stmt.close();
			conn.close();
		}catch(SQLException se){
			//Handle errors for JDBC
			se.printStackTrace();
		}catch(Exception e){
			//Handle errors for Class.forName
			e.printStackTrace();
		}finally{
			//finally block used to close resources

			try{
				if(conn!=null)
					conn.close();
			}catch(SQLException se){
				se.printStackTrace();
			}//end finally try
		}//end try
		System.out.println("Goodbye!");

	}//end main

}

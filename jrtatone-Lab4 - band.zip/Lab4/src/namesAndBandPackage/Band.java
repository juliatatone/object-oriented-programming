package namesAndBandPackage;

import java.util.ArrayList;

/** 
 * A band with persons.
 * @author juliatatone
 *
 */
public class Band implements Membership {
	ArrayList<Person> band = new ArrayList<Person>() ; 

/**
 * adding person to band
 * @param person
 */
public void addBandMember(Person person) {
	

	if(!band.contains(person)) {
		band.add(person);
		}	
}
/**
 * Making the band
 * @return
 */
public ArrayList<Person> getBand(){
	
return band;
}
protected int countBand(){
	band.size();
}
	
	
	

}

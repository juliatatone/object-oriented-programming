package namesAndBandPackage;
import java.util.ArrayList;
/**
 * Main class 
 * @author juliatatone
 *
 */
public class MainLab2 {

	public static void main(String[] args) {
		//band1 members
		Person matt = new Person("Matt");
		Person zach = new Person ("Zach");
		Band band1 = new Band();
		Band band2 = new Band();
		//band2 members
		Person drummer = new Person ("Mark");
		Person singer = new Person ("Rachel");
		//joe and diane are conductors
		Person diane = new Person("Diane");
		Person joe = new Person("Joe");
		Symphony symphony1 = new Symphony(joe);
		Symphony symphony2 = new Symphony(diane);
		
		band1.addBandMember(matt);
		band1.addBandMember(zach);
		System.out.println(band1);
		band2.addBandMember(singer);
		band2.addBandMember(drummer);
		symphony1.addBandMember(joe);
		symphony2.addBandMember(diane);
		
		//ArrayList of bands
		ArrayList<Band> bands = new ArrayList<Band>();
		bands.add(band1);
		bands.add(symphony1);
		bands.add(symphony2);
		
		for(Band b: bands) {
			System.out.println(bands.size());
			
		}
		
		Club cheeseClub = new Club("Cheese Club");
		cheeseClub.addClubMember("Carl");
		System.out.println(cheeseClub.countBand());
		
		
		
		
		band1.getBand().size();
		System.out.println(band1.getBand().size());
	}
}

package namesAndBandPackage;
import java.util.ArrayList;

public class Club implements Membership{
	ArrayList<String> names = new ArrayList<String>();
	private String type;
	private String name;
	
	public Club(String type) {
		this.type = type;
		
	}
	public void addClubMember(String name) {
		names.add(name);
	}
	public int countBand() {
		return names.size();
	}
	
	}
	


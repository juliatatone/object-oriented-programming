package namesAndBandPackage;

public interface Membership {
//returns the number of members
	public int countBand();
	}


package namesAndBandPackage;

public class Symphony extends Band{
	private Person conductor;
	
	public Symphony (Person conductor) {
		this.conductor = conductor;
		
	}
	public Person getConductor() {
		return this.conductor;
	}
	public void setConductor(Person newConductor) {
		this.conductor = newConductor;
	}
}

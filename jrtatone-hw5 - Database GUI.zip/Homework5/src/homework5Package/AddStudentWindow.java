// Vibhuti Pathare and Julia Tatone
package homework5Package;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
/**
 * AddStudentWindow class that creates a frame for adding students to a list
 * @author juliatatone
 *
 */
public class AddStudentWindow extends JFrame{
	private DefaultListModel<String> listModel;
	private Students students;
	private JTextField lastNameField;
	private JTextField firstNameField;
	private JTextField studentIDField;
	/**
	 * initialize the list and object student
	 * @param listModel
	 * @param students
	 */
	public AddStudentWindow(DefaultListModel<String> listModel, Students students) {
		// TODO Auto-generated constructor stub
		this.listModel = listModel;
		this.students = students;
		run();
		
	}
	/**
	 * Create panel and its components, add to frame
	 */
	private void run() {
		JPanel studentInfo = new JPanel();
		this.setSize(300, 400);
		JLabel lastNameLabel = new JLabel("Last Name:");
		JLabel firstNameLabel = new JLabel("First Name:");
		JLabel studentIDLabel = new JLabel("Student ID:");
		lastNameField = new JTextField(15);
		firstNameField = new JTextField(15);
		studentIDField = new JTextField(10);
		studentInfo.add(lastNameLabel);
		studentInfo.add(lastNameField);
		studentInfo.add(firstNameLabel);
		studentInfo.add(firstNameField);
		studentInfo.add(studentIDLabel);
		studentInfo.add(studentIDField);
		this.add(studentInfo);
		
		/**create a button panel
		 * 
		 */
		JPanel buttonPanel= new JPanel();
		JButton okButton = new JButton("OK");
		JButton cancelButton = new JButton("Cancel");
		buttonPanel.add(okButton);
		buttonPanel.add(cancelButton);
		studentInfo.add(buttonPanel);
		
		/**create listeners
		 * 
		 */
		okButton.addActionListener(new OKListener());
		cancelButton.addActionListener(new CancelListener());
		
		this.setVisible(true);
	}
	/**
	 * classes for both listeners and what actions they must perform
	 * @author juliatatone
	 *
	 */
	private class OKListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			String ln = lastNameField.getText();
			String fn = firstNameField.getText();
			String id = studentIDField.getText();
			
			Student a = new Student(id, fn, ln);
			
			students.addStudents(a);
			listModel.add(students.amountOfStudents()- 1, a.toString());
			
		}

	}
	private class CancelListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			AddStudentWindow.this.dispose();
			

		}

	}
	
}

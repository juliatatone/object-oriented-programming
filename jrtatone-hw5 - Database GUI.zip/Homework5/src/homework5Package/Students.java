// Vibhuti Pathare and Julia Tatone
package homework5Package;

import java.util.ArrayList;

public class Students {
	ArrayList<Student> listOfStudents = new ArrayList<Student>();
	
	public void addStudents(Student s) {
		listOfStudents.add(s);
	}
	public void removeStudents(Student s) {
		listOfStudents.remove(s);
	}
	public int amountOfStudents() {
		int amount = listOfStudents.size();
		return amount;
	}
	public void remove(int index) {
		listOfStudents.remove(index);
	}
	}

// Vibhuti Pathare and Julia Tatone
package homework5Package;

import java.lang.StringBuilder;
import java.util.ArrayList;

public class Student {
	private String studID;
	private String firstName;
	private String lastName;
	

	/**
	 * constructor for the student class with three parameters
	 * 
	 * @param studID
	 * @param firstName
	 * @param lastName
	 */
	public Student(String studID, String firstName, String lastName) {
		this.setStudID(studID);
		this.firstName = firstName;
		this.lastName = lastName;

	}

	/**
	 * set the student id
	 * 
	 * @param studID
	 */
	public void setStudID(String studID) {
		this.studID = studID;
	}

	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb = sb.append(this.firstName);
		sb = sb.append(this.lastName);
		sb = sb.append(" ");
		sb = sb.append(this.studID);
		String completedString = sb.toString();
		return completedString;
	}
}

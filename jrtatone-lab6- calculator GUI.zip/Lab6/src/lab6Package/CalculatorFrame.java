package lab6Package;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridBagLayout;
import javax.swing.JTextField;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;

public class CalculatorFrame extends JFrame {

	private JPanel contentPane;
	private JTextField inputField1;
	private JTextField inputField2;
	private JButton buttonDivide;
	private JLabel labelAnswer;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CalculatorFrame frame = new CalculatorFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CalculatorFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 250, 350);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{0, 0, 0};
		gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0, 0};
		gbl_contentPane.columnWeights = new double[]{1.0, 1.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		inputField1 = new JTextField();
		GridBagConstraints gbc_inputField1 = new GridBagConstraints();
		gbc_inputField1.insets = new Insets(0, 0, 5, 5);
		gbc_inputField1.fill = GridBagConstraints.HORIZONTAL;
		gbc_inputField1.gridx = 0;
		gbc_inputField1.gridy = 0;
		contentPane.add(inputField1, gbc_inputField1);
		inputField1.setColumns(10);
		
		inputField2 = new JTextField();
		GridBagConstraints gbc_inputField2 = new GridBagConstraints();
		gbc_inputField2.insets = new Insets(0, 0, 5, 0);
		gbc_inputField2.fill = GridBagConstraints.HORIZONTAL;
		gbc_inputField2.gridx = 1;
		gbc_inputField2.gridy = 0;
		contentPane.add(inputField2, gbc_inputField2);
		inputField2.setColumns(10);
		
		JButton buttonAdd = new JButton("Add");
		buttonAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int a = gbc_inputField1.getText();
				int b = gbc_inputField2.getText();
				
				int sum = a+b;
				labelAnswer.setText(sum);
			}
		});
		GridBagConstraints gbc_buttonAdd = new GridBagConstraints();
		gbc_buttonAdd.fill = GridBagConstraints.HORIZONTAL;
		gbc_buttonAdd.insets = new Insets(0, 0, 5, 5);
		gbc_buttonAdd.gridx = 0;
		gbc_buttonAdd.gridy = 1;
		contentPane.add(buttonAdd, gbc_buttonAdd);
		
		JButton buttonSubtract = new JButton("Subtract");
		GridBagConstraints gbc_buttonSubtract = new GridBagConstraints();
		gbc_buttonSubtract.fill = GridBagConstraints.HORIZONTAL;
		gbc_buttonSubtract.insets = new Insets(0, 0, 5, 0);
		gbc_buttonSubtract.gridx = 1;
		gbc_buttonSubtract.gridy = 1;
		contentPane.add(buttonSubtract, gbc_buttonSubtract);
		
		JButton buttonMultiply = new JButton("Multiply");
		GridBagConstraints gbc_buttonMultiply = new GridBagConstraints();
		gbc_buttonMultiply.fill = GridBagConstraints.HORIZONTAL;
		gbc_buttonMultiply.insets = new Insets(0, 0, 5, 5);
		gbc_buttonMultiply.gridx = 0;
		gbc_buttonMultiply.gridy = 2;
		contentPane.add(buttonMultiply, gbc_buttonMultiply);
		
		buttonDivide = new JButton("Divide");
		GridBagConstraints gbc_buttonDivide = new GridBagConstraints();
		gbc_buttonDivide.insets = new Insets(0, 0, 5, 0);
		gbc_buttonDivide.fill = GridBagConstraints.HORIZONTAL;
		gbc_buttonDivide.gridx = 1;
		gbc_buttonDivide.gridy = 2;
		contentPane.add(buttonDivide, gbc_buttonDivide);
		
		labelAnswer = new JLabel("0");
		GridBagConstraints gbc_labelAnswer = new GridBagConstraints();
		gbc_labelAnswer.gridwidth = 2;
		gbc_labelAnswer.insets = new Insets(0, 0, 0, 5);
		gbc_labelAnswer.gridx = 0;
		gbc_labelAnswer.gridy = 3;
		contentPane.add(labelAnswer, gbc_labelAnswer);
	}

}
